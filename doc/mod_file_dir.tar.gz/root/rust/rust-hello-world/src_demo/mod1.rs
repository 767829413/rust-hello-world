/*
模块映射到文件
*/
pub const MESSAGE: &str = "hi";
