/*
模块映射到文件夹
*/
pub mod mod2_a;
pub mod mod2_b;

pub const MESSAGE2: &str = "hi2";
