pub const MESSAGE2_B: &str = "hi2_B";
